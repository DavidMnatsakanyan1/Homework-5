   const lib = require('./file.js');
   let path = "matrixnumbers.txt";
   let matrixArrays = [[6,8,7],[7,5,4],[1,2,3],[5,6],[23]];
   lib.saveFile(matrix,path);

   let matrix1=lib.loadFile(path);
   if(lib.differentMatrix(matrix1)==0){
    
      console.log(Sum(matrix1));
}
   else if(lib.differentMatrix(matrix1)==1){
       console.log(Multiply(matrix1));
}
else{
       console.log(transposeOfMatrix(matrix1));
}
       
    function Multiply(mtrx){
        s=1;
        for(let i = 0;i<mtrx.length;i++){
        for(let j= 0;j< mtrx[i].length;j++){
            s*=mtrx[i][j];

        }
    }
    return s;
}

        function Sum(mtrx){
        let s=0;
        for(let i = 0;i<mtrx.length;i++){
        for(let j= 0;j< mtrx[i].length;j++){
            s+=mat[i][j];
        }
    }
    return s;
   }

    function transposeOfMatrix(k){
    if(lib.differentMatrix(k)==1 || lib.differentMatrix(k)==2){
        
        let fmat=[];
       
            let height=k.length;
            let width =k[0].length;
            for(i=0;i<width;i++){
            let row=[];
            for(j=0;j<height;j++){
                row.push(k[j][i])
            }
            fmat.push(row);
        }
        return fmat;
    }
    else{
        return null;
    }
}