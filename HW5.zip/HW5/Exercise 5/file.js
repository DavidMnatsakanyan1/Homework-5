   let fs = require('fs');
   function transformToString(matrx){
    let s = "";
    for(let i = 0;i<matrx.length;i++)
    {   
        for(let j = 0;j<matrx[i].length;j++)
        {
            s+=matrx[i][j] + ",";
        }
        s+="|";
     
    }
        
    return s;
}

         function fromStringToMatrix(str){
       str+='';
       let result=[];  
       let arrays=str.split('|');
       for(let i=0;i<arrays.length-1;i++){
        f=arrays[i].split(',');
        let row=[];
        for(let j = 0;j<f.length-1;j++){
            row.push(parseInt(f[j]));
        }
        result.push(row);
    }
       return result;

}
       function  saveFile(mtrx, path){
    
         fs.writeFileSync(path, fromStringToMatrix(mtrx),(err)=>{
        if(err){
            console.error(err);
            return;
            }

    });
}
    function  loadFile(path){
  
      let str= fs.readFileSync( path, {encoding:'utf8'},
        (err)=>{
            if(err){
                console.error(err);
                return;
            }

        });
    
     return fromStringToMatrix(str);
}
     function differentMatrix(m){
       let len = m.length;
       let len2=m[0].length;
       for(let i=0;i<m.length;i++){
        if(m[i].length==undefined)
        {
            return -1;
        }
        if(m[i].length!=len2){
            return 0;
        }
        
    }
        if(len == len2){
        return 2
        }
       else{
          return 1;
    }
}

module.exports = {loadFile,saveFile,differentMatrix}