function determineMatrixType (m) {
  let arrayCount = m.length;
  let isMatrixSquare = true;
  let isMatrixRectangular = true;
  let isMatrix2D = m.constructor == Array;

  if (isMatrix2D == false)
     return -1;

  for(let i = 0; i < arrayCount; i++) {
    if(m[i].constructor != Array)
      isMatrix2D = false;
      
    if(m[i].length != arrayCount)
      isMatrixSquare = false;
    
    if(m[i].length != m[0].length)
    	isMatrixRectangular = false;
  }
  
  if (isMatrix2D == true && isMatrixSquare == true)
  	return 2;
    
  if (isMatrix2D == true && isMatrixRectangular == true)
  	return 1;
    
  if (isMatrix2D == true)
    return 0;
    
  return -1;
}

console.log(determineMatrixType([[1,2,3,4,5],[1,4,6,7,5],[1,2,3,4,4],[1,4,6,7,8],[1,4,6,7,8]]));
console.log(determineMatrixType([[1,2],[1,4],[8,5]]));
console.log(determineMatrixType([[1,2],[1,4,9]]));
console.log(determineMatrixType([1,2]));
console.log(determineMatrixType([[1,2],"ddfdf"]));
console.log(determineMatrixType(1));