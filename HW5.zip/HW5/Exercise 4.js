function spiralMatrix(n) {

  if (n < 0 || n % 2 == 0) {
   console.log("N should be a positive odd number!");
   return;
  }

  let result = []; // We will save the result here.
  
  for (let i = 0; i < n; i++) {
     result.push([]);
  }
  
  let x = Math.floor(n / 2); // Center of the matrix 
  let y = Math.floor(n / 2); // Center of the matrix 
  let number = 1; // We will start from 1 which will be in the center and then increment every time.
  let direction = 0; // 0 means to go up, 1 means to go right, 2 means to go down and 3 means to go left.
  let moveSize = 1; // After moving from center we need to increment this because our square becomes bigger.
  
  for (let i=0; i < n; i++)
  {
     // During the last step we need to change the direction only once.
     // During all other steps we do that twice.
     let changeDirectionSteps = i == n - 1 ? 1 : 2;
     for (let j=0; j < changeDirectionSteps; j++)
     {
       for (let k=0; k < moveSize; k++)
       {
         result[x][y] = number;
         number++;
         
         if (direction == 0) // Go up.
            x--;
         else if (direction == 1) // Go right.
            y++;
         else if (direction == 2) // Go down.
            x++;
         else if (direction == 3) // Go left.
            y--;
       }
       
       direction = (direction + 1) % 4; // Change direction to the next one.
     }
     moveSize = moveSize + 1;
  }
   
  return result;
}

console.log(spiralMatrix(1));
console.log(spiralMatrix(3));
console.log(spiralMatrix(5));
console.log(spiralMatrix(7));
console.log(spiralMatrix(9));